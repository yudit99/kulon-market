
import { useState } from "react";

interface Produk {
  id: number;
  nama: string;
  harga: number;
  satuan: string;
}

interface ItemKeranjang extends Produk {
  jumlah: number;
}

export default function App() {
  const [keranjang, setKeranjang] = useState<ItemKeranjang[]>([]);

  const produk: Produk[] = [
    { id: 1, nama: "Sayur Bayam", harga: 10000, satuan: "kg" },
    { id: 2, nama: "Wortel", harga: 12000, satuan: "kg" },
    { id: 3, nama: "Tomat", harga: 8000, satuan: "kg" }
  ];

  const tambahKeKeranjang = (produk: Produk) => {
    setKeranjang((prev) => {
      const sudahAda = prev.find((item) => item.id === produk.id);
      if (sudahAda) {
        return prev.map((item) =>
          item.id === produk.id
            ? { ...item, jumlah: item.jumlah + 1 }
            : item
        );
      }
      return [...prev, { ...produk, jumlah: 1 }];
    });
  };

  const kurangDariKeranjang = (produk: Produk) => {
    setKeranjang((prev) => {
      const item = prev.find((i) => i.id === produk.id);
      if (item && item.jumlah === 1) {
        return prev.filter((i) => i.id !== produk.id);
      }
      return prev.map((i) =>
        i.id === produk.id ? { ...i, jumlah: i.jumlah - 1 } : i
      );
    });
  };

  const totalHarga = keranjang.reduce(
    (total, item) => total + item.harga * item.jumlah,
    0
  );

  const formatRupiah = (angka: number) => angka.toLocaleString("id-ID");

  const buatPesanWA = () => {
    const nomorWA = "6281234567890"; // Ganti sesuai kebutuhan
    let pesan = "Halo, saya ingin memesan:\n";
    keranjang.forEach((item) => {
      pesan += `- ${item.nama} ${item.jumlah} ${item.satuan} (Rp ${formatRupiah(
        item.harga * item.jumlah
      )})\n`;
    });
    pesan += `Total: Rp ${formatRupiah(totalHarga)}`;
    return `https://wa.me/${nomorWA}?text=${encodeURIComponent(pesan)}`;
  };

  return (
    <div className="p-4 font-sans">
      <h1 className="text-2xl font-bold mb-4">Kulon Sayur</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {produk.map((p) => (
          <div
            key={p.id}
            className="border rounded-xl p-3 shadow hover:shadow-lg transition"
          >
            <h2 className="text-lg font-semibold">{p.nama}</h2>
            <p className="text-gray-600">
              Harga: Rp {formatRupiah(p.harga)} / {p.satuan}
            </p>
            <button
              onClick={() => tambahKeKeranjang(p)}
              className="mt-2 px-3 py-1 bg-green-500 hover:bg-green-600 text-white rounded-md"
            >
              + Tambah
            </button>
          </div>
        ))}
      </div>

      <h2 className="text-xl font-semibold mt-6 mb-2">Keranjang</h2>
      {keranjang.length === 0 ? (
        <p className="text-gray-500">Keranjang kosong</p>
      ) : (
        <div className="space-y-2">
          {keranjang.map((item) => (
            <div
              key={item.id}
              className="flex items-center justify-between border p-2 rounded-md"
            >
              <div>
                {item.nama} ({item.jumlah} {item.satuan})
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => kurangDariKeranjang(item)}
                  className="px-2 py-1 bg-red-500 hover:bg-red-600 text-white rounded"
                >
                  -
                </button>
                <button
                  onClick={() => tambahKeKeranjang(item)}
                  className="px-2 py-1 bg-green-500 hover:bg-green-600 text-white rounded"
                >
                  +
                </button>
              </div>
            </div>
          ))}
          <div className="mt-2 font-semibold">
            Total Harga: Rp {formatRupiah(totalHarga)}
          </div>
          <a
            href={buatPesanWA()}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block mt-3 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-xl"
          >
            Checkout via WhatsApp
          </a>
        </div>
      )}
    </div>
  );
}
